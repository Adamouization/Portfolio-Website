bundle exec jekyll serve --watch
open http://127.0.0.1:4000
